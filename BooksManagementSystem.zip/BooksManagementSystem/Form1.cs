﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BooksManagementSystem
{
    public partial class Form1 : Form
    {

        SqlConnection
            conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\yonit\Desktop\CST452\bookdb.mdf;Integrated Security=True;Connect Timeout=30");
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public bool checkConnection()
        {
            if(conn.State == ConnectionState.Closed) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
           if (checkConnection())
            {
                try
                {
                    conn.Open();

                    string selectdata = "SELECT * FROM users WHERE username = @username AND password = @password";

                    using(SqlCommand cmd = new SqlCommand(selectdata, conn))
                    {
                        cmd.Parameters.AddWithValue("@username", username.Text.Trim());
                        cmd.Parameters.AddWithValue("@password", passwordtxt.Text.Trim());

                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        if(table.Rows.Count > 0)
                        {
                            MessageBox.Show("Login Successful!!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Dashboard dashboard = new Dashboard();
                            dashboard.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex) 
                {
                    MessageBox.Show("Connection Failed" + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                { 
                    conn.Close();
                }
           }
        }
    }
}
