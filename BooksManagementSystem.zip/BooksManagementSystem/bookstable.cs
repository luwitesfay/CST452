﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BooksManagementSystem
{
    class bookstable
    {
        public int Id { get; set; }
        public string BookName { get; set; }
        public string Description { get; set; }
        public string AuthorName { get; set; }
        public string Price { get; set; }
        public string Amount { get; set; }


        public List<bookstable> AllBooksData()
        {
            List<bookstable> listData = new List<bookstable>();

            using (SqlConnection
           conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\yonit\Desktop\CST452\bookdb.mdf;Integrated Security=True;Connect Timeout=30"))

            {
                conn.Open();

                string selectdata = "SELECT * FROM books";

                using (SqlCommand cmd = new SqlCommand(selectdata, conn))
                {
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        bookstable bookstbl = new bookstable();
                        bookstbl.Id = (int)reader["id"];
                        bookstbl.BookName = reader["bookname"].ToString();
                        bookstbl.AuthorName = reader["authorname"].ToString();
                        bookstbl.Description = reader["description"].ToString();
                        bookstbl.Price = reader["price"].ToString();
                        bookstbl.Amount = reader["amount"].ToString();

                        listData.Add(bookstbl);

                    }


                }
            }

            return listData;
        }
    }
}
