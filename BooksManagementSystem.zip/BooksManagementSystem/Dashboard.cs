﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Diagnostics;
using System.Security.Policy;

namespace BooksManagementSystem
{
    public partial class Dashboard : Form
    {

        SqlConnection
           conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\yonit\Desktop\CST452\bookdb.mdf;Integrated Security=True;Connect Timeout=30");

        public Dashboard()
        {
            InitializeComponent();

            displayAllBooks();
        }
        public bool checkConnection()
        {
            if (conn.State == ConnectionState.Closed)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void logout_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();

            this.Hide();
        }

        public void displayAllBooks()
        {
            bookstable bookstbl = new bookstable();
            List<bookstable> listData = bookstbl.AllBooksData();

            booksdataGridView.DataSource = listData;


        }
        private void addbtn_Click(object sender, EventArgs e)
        {

            if(nametxt.Text == ""  || authortxt.Text == "" || decriptiontxt.Text == "" || pricetxt.Text == "" || amounttxt.Text == "")
            {
                MessageBox.Show("All fields are required. You have one or more empty fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                if (checkConnection())
                {
                    try
                    {
                        conn.Open();

                        string selectdata = "SELECT * FROM books WHERE bookname = @bookname";

                        using (SqlCommand cmd = new SqlCommand(selectdata, conn))
                        {
                            cmd.Parameters.AddWithValue("@bookname", nametxt.Text.Trim());

                            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                            DataTable table = new DataTable();
                            adapter.Fill(table);

                            if (table.Rows.Count > 0)
                            {
                                MessageBox.Show("Book already exsist", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);


                            }
                            else
                            {
                                string insertData = "Insert into books (bookname, authorname, description, price, amount)" + "VALUES(@bookname, @authorname, @description, @price, @amount)";


                                using (SqlCommand insertDT = new SqlCommand(insertData, conn))
                                {
                                    insertDT.Parameters.AddWithValue("@bookname", nametxt.Text.Trim());
                                    insertDT.Parameters.AddWithValue("@authorname", authortxt.Text.Trim());
                                    insertDT.Parameters.AddWithValue("@description", decriptiontxt.Text.Trim());
                                    insertDT.Parameters.AddWithValue("@price", pricetxt.Text.Trim());
                                    insertDT.Parameters.AddWithValue("@amount", amounttxt.Text.Trim());

                                    insertDT.ExecuteNonQuery();
                                    clear();
                                    displayAllBooks();

                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Connection Failed" + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }    
        }

        public void clear()
        {
            nametxt.Text = "";
            authortxt.Text = "";
            decriptiontxt.Text = "";
            pricetxt.Text = "";
            amounttxt.Text = "";
        }

        public void clearbtn_Click(object sender, EventArgs e)
        {
            clear();

        }

        private int getId = 0;
        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (nametxt.Text == "" || authortxt.Text == "" || decriptiontxt.Text == "" || pricetxt.Text == "" || amounttxt.Text == "")
            {
                MessageBox.Show("All fields are required. You have one or more empty fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (checkConnection())
                {
                    try
                    {
                        conn.Open();


                        string updateData = "UPDATE  books SET bookname = @bookname, authorname = @authorname, description = @description, price = @price, amount = @amount WHERE id = @id";


                                using (SqlCommand updateDT = new SqlCommand(updateData, conn))
                                {
                            updateDT.Parameters.AddWithValue("@id", getId);
                            updateDT.Parameters.AddWithValue("@bookname", nametxt.Text.Trim());
                            updateDT.Parameters.AddWithValue("@authorname", authortxt.Text.Trim());
                            updateDT.Parameters.AddWithValue("@description", decriptiontxt.Text.Trim());
                            updateDT.Parameters.AddWithValue("@price", pricetxt.Text.Trim());
                            updateDT.Parameters.AddWithValue("@amount", amounttxt.Text.Trim());

                            updateDT.ExecuteNonQuery();
                                    clear();
                                    displayAllBooks();
                            MessageBox.Show("Book updated successfully" , "Informational Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }
                            
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Connection Failed" + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
                if (checkConnection())
                {
                    try
                    {
                    conn.Open();


                    string DeleteeData = "DELETE FROM books WHERE Id = @Id  ";

                        using (SqlCommand deleteDT = new SqlCommand(DeleteeData, conn))
                        {
                            deleteDT.Parameters.AddWithValue("@Id", getId);


                        deleteDT.ExecuteNonQuery();
                                    clear();
                                    displayAllBooks();
                        MessageBox.Show("Book deleted successfully", "Informational Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                            
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Connection Failed" + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            
        }
    }
    
}
