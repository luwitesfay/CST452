﻿namespace BooksManagementSystem
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logout = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clearbtn = new System.Windows.Forms.Button();
            this.deletebtn = new System.Windows.Forms.Button();
            this.updatebtn = new System.Windows.Forms.Button();
            this.addbtn = new System.Windows.Forms.Button();
            this.amounttxt = new System.Windows.Forms.TextBox();
            this.amount = new System.Windows.Forms.Label();
            this.pricetxt = new System.Windows.Forms.TextBox();
            this.price = new System.Windows.Forms.Label();
            this.decriptiontxt = new System.Windows.Forms.TextBox();
            this.description = new System.Windows.Forms.Label();
            this.authortxt = new System.Windows.Forms.TextBox();
            this.author = new System.Windows.Forms.Label();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.booksdataGridView = new System.Windows.Forms.DataGridView();
            this.title = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.booksdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // logout
            // 
            this.logout.Location = new System.Drawing.Point(1827, 58);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(157, 64);
            this.logout.TabIndex = 1;
            this.logout.Text = "Logout";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.clearbtn);
            this.panel1.Controls.Add(this.deletebtn);
            this.panel1.Controls.Add(this.updatebtn);
            this.panel1.Controls.Add(this.addbtn);
            this.panel1.Controls.Add(this.amounttxt);
            this.panel1.Controls.Add(this.amount);
            this.panel1.Controls.Add(this.pricetxt);
            this.panel1.Controls.Add(this.price);
            this.panel1.Controls.Add(this.decriptiontxt);
            this.panel1.Controls.Add(this.description);
            this.panel1.Controls.Add(this.authortxt);
            this.panel1.Controls.Add(this.author);
            this.panel1.Controls.Add(this.nametxt);
            this.panel1.Controls.Add(this.name);
            this.panel1.Controls.Add(this.booksdataGridView);
            this.panel1.Location = new System.Drawing.Point(12, 152);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1972, 1011);
            this.panel1.TabIndex = 2;
            // 
            // clearbtn
            // 
            this.clearbtn.BackColor = System.Drawing.Color.Snow;
            this.clearbtn.Font = new System.Drawing.Font("Segoe UI", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearbtn.Location = new System.Drawing.Point(267, 603);
            this.clearbtn.Name = "clearbtn";
            this.clearbtn.Size = new System.Drawing.Size(216, 76);
            this.clearbtn.TabIndex = 16;
            this.clearbtn.Text = "Clear";
            this.clearbtn.UseVisualStyleBackColor = false;
            this.clearbtn.Click += new System.EventHandler(this.clearbtn_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.BackColor = System.Drawing.Color.IndianRed;
            this.deletebtn.Font = new System.Drawing.Font("Segoe UI", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletebtn.Location = new System.Drawing.Point(43, 603);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(216, 76);
            this.deletebtn.TabIndex = 15;
            this.deletebtn.Text = "Delete";
            this.deletebtn.UseVisualStyleBackColor = false;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.updatebtn.Font = new System.Drawing.Font("Segoe UI", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.Location = new System.Drawing.Point(267, 505);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(216, 76);
            this.updatebtn.TabIndex = 14;
            this.updatebtn.Text = "Update";
            this.updatebtn.UseVisualStyleBackColor = false;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // addbtn
            // 
            this.addbtn.BackColor = System.Drawing.Color.LawnGreen;
            this.addbtn.Font = new System.Drawing.Font("Segoe UI", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbtn.Location = new System.Drawing.Point(43, 505);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(216, 76);
            this.addbtn.TabIndex = 13;
            this.addbtn.Text = "Add";
            this.addbtn.UseVisualStyleBackColor = false;
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // amounttxt
            // 
            this.amounttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amounttxt.Location = new System.Drawing.Point(251, 378);
            this.amounttxt.Name = "amounttxt";
            this.amounttxt.Size = new System.Drawing.Size(269, 44);
            this.amounttxt.TabIndex = 11;
            // 
            // amount
            // 
            this.amount.AutoSize = true;
            this.amount.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amount.Location = new System.Drawing.Point(80, 374);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(146, 45);
            this.amount.TabIndex = 10;
            this.amount.Text = "Amount:";
            // 
            // pricetxt
            // 
            this.pricetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricetxt.Location = new System.Drawing.Point(251, 308);
            this.pricetxt.Name = "pricetxt";
            this.pricetxt.Size = new System.Drawing.Size(269, 44);
            this.pricetxt.TabIndex = 9;
            // 
            // price
            // 
            this.price.AutoSize = true;
            this.price.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.price.Location = new System.Drawing.Point(127, 304);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(99, 45);
            this.price.TabIndex = 8;
            this.price.Text = "Price:";
            // 
            // decriptiontxt
            // 
            this.decriptiontxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.decriptiontxt.Location = new System.Drawing.Point(251, 237);
            this.decriptiontxt.Name = "decriptiontxt";
            this.decriptiontxt.Size = new System.Drawing.Size(269, 44);
            this.decriptiontxt.TabIndex = 7;
            // 
            // description
            // 
            this.description.AutoSize = true;
            this.description.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.description.Location = new System.Drawing.Point(35, 233);
            this.description.Name = "description";
            this.description.Size = new System.Drawing.Size(194, 45);
            this.description.TabIndex = 6;
            this.description.Text = "Description:";
            // 
            // authortxt
            // 
            this.authortxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.authortxt.Location = new System.Drawing.Point(251, 163);
            this.authortxt.Name = "authortxt";
            this.authortxt.Size = new System.Drawing.Size(269, 44);
            this.authortxt.TabIndex = 5;
            // 
            // author
            // 
            this.author.AutoSize = true;
            this.author.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.author.Location = new System.Drawing.Point(3, 159);
            this.author.Name = "author";
            this.author.Size = new System.Drawing.Size(226, 45);
            this.author.TabIndex = 4;
            this.author.Text = "Author Name:";
            // 
            // nametxt
            // 
            this.nametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nametxt.Location = new System.Drawing.Point(251, 97);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(269, 44);
            this.nametxt.TabIndex = 3;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(28, 93);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(198, 45);
            this.name.TabIndex = 2;
            this.name.Text = "Book Name:";
            // 
            // booksdataGridView
            // 
            this.booksdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.booksdataGridView.Location = new System.Drawing.Point(553, 43);
            this.booksdataGridView.Name = "booksdataGridView";
            this.booksdataGridView.RowHeadersWidth = 82;
            this.booksdataGridView.RowTemplate.Height = 33;
            this.booksdataGridView.Size = new System.Drawing.Size(1390, 919);
            this.booksdataGridView.TabIndex = 0;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.ForeColor = System.Drawing.Color.Yellow;
            this.title.Location = new System.Drawing.Point(556, 58);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(790, 50);
            this.title.TabIndex = 4;
            this.title.Text = "Books Inventory Management System";
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(2084, 1219);
            this.Controls.Add(this.title);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.logout);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.booksdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button clearbtn;
        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.Button addbtn;
        private System.Windows.Forms.TextBox amounttxt;
        private System.Windows.Forms.Label amount;
        private System.Windows.Forms.TextBox pricetxt;
        private System.Windows.Forms.Label price;
        private System.Windows.Forms.TextBox decriptiontxt;
        private System.Windows.Forms.Label description;
        private System.Windows.Forms.TextBox authortxt;
        private System.Windows.Forms.Label author;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.DataGridView booksdataGridView;
        private System.Windows.Forms.Label title;
    }
}